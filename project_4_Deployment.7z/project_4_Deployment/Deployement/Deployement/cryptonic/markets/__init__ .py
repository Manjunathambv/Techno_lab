"""
Interface for manipulating data from different markets.
"""
