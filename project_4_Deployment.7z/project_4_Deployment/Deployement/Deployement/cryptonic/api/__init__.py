"""
HTTP API interface for Cryptonic.
"""

__version__ = 1
